# CAPABILITY MATRIX

Update at runtime when capabilities are discovered.

| Capability | Status | Evidence/Notes |
|---|---|---|
| Filesystem | UNKNOWN | |
| Shell | UNKNOWN | |
| Git | UNKNOWN | |
| GitHub | UNKNOWN | |
| Web research | UNKNOWN | |
| Browser | UNKNOWN | |
| Screenshots | UNKNOWN | |
| Database tools | UNKNOWN | |
| Docker/container | UNKNOWN | |
| Subagents | UNKNOWN | |
| Vector search | UNKNOWN | |
| Code index/LSP | UNKNOWN | |
| Graph query | UNKNOWN | |
| Deploy access | UNKNOWN | |
| Production access | UNKNOWN | |
| Native subagents | UNKNOWN | |
| Multi-process execution | UNKNOWN | |
| Parallel tool execution | UNKNOWN | |
| Git worktrees | UNKNOWN | |
| Isolated agent contexts | UNKNOWN | |
| Agent messaging/shared state | UNKNOWN | |
| Model routing | UNKNOWN | |
